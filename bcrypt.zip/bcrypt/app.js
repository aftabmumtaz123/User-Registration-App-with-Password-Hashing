const express = require('express');
const bcrypt = require('bcryptjs');
require('./db/conn');
const Users = require('./models/user');

const app = express();
const port = 3001;

// Set up EJS as the template engine
app.set('view engine', 'ejs');

// Middleware to parse URL-encoded bodies (form data)
app.use(express.urlencoded({ extended: true }));

app.get('/', (req, res) => {
    res.render('index', { data: 'Aftab Mumtaz' });
});

app.post('/submit', async (req, res) => {
    try {
        // Encrypt the password before saving
        const hashedPassword = await bcrypt.hash(req.body.password, 10);

        // Create a new user with the hashed password
        const user = new Users({
            name: req.body.name,
            email: req.body.email,
            password: hashedPassword,
        });

        await user.save();

        // Render the index page with a success message
        res.status(201).render('successch', { data: 'User successfully registered!' });
    } catch (e) {
        res.status(400).send(e);
    }
});

app.listen(port, () => {
    console.log(`App is running at the port ${port}`);
});
