const mongoose = require("mongoose");

mongoose.connect("mongodb://localhost:27017/bcryptjs").then(()=>{
    console.log("Connection Successful");
}).catch((e)=>{
    console.log("There is some error in connection",e);
});