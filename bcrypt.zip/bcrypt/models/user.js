const db = require('mongoose');


const userSchema = new db.Schema(
    {
        name: {
            type: String,
            required: true
        },
        email: {
            type: String,
            required: true,
            unique: true
        },
        password: {
            required: true,
            type: String
        }
    },{timestamps: true}
);

const User = db.model('user',userSchema);
module.exports = User;